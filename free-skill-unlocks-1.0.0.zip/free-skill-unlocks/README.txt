FREE SKILL UNLOCKS 1.0.0  (Enshrouded Mod Loader - Lua)
=======================================================

What it does
  Every skill tree node costs 0 skill points (configurable in config.txt), so a
  character can unlock as many skills as they like. It changes nothing else: no
  recipes, world presets, perk, durability or dismantle values.

Requirements
  Enshrouded Mod Loader (EML, the dbghelp.dll proxy) on the server and on each
  authorised player's PC.

INSTALL - DEDICATED SERVER
  1. Stop the server.
  2. Copy the whole "free-skill-unlocks" folder into the server's "mods" folder:
       <server root>\mods\free-skill-unlocks\mod.json
       <server root>\mods\free-skill-unlocks\config.txt
       <server root>\mods\free-skill-unlocks\src\mod.lua
  3. Start the server. EML patches the game data on startup.
  4. Check the newest EML log (<server root>\logs\<date>.eml.log) for:
       [Free Skill Unlocks] v1.0.0 on server: trees=1 nodes=... costLoweredTo0=...
     "trees=0" means a game update changed the data layout and the mod did nothing.

INSTALL - EACH AUTHORISED PLAYER
  Copy the same folder (with the same config.txt) into the game's mods folder:
       ...\steamapps\common\Enshrouded\mods\free-skill-unlocks\
  Start the game. The skill tree then shows 0-cost nodes.

Who gets free skills ("authorised players")
  This is a game-data patch, so it applies to whoever runs it. Only players who
  have the mod on their own PC get free skills. Players without it see normal
  costs and their game keeps them to their earned points.
  This is not tamper-proof: anyone who gets a copy of the mod folder can use it.
  Hand the folder only to the players you authorise.

BEFORE FIRST USE - BACK UP CHARACTERS
  Skills are checked by whoever runs the world: your own game in solo or when
  you host, or the server on a dedicated server. Free skills only work in worlds
  that run this mod. If you join a world whose host or server does not have it,
  that host resets the skills you did not pay for. Your game may still show 0
  costs there, but the unlocks will not stick. Back up your character save
  before the first use.
  If the mod is removed later, a character may have spent more points than it
  has earned. Use the in-game skill reset with the mod still installed before
  removing it.

Settings (config.txt)
  enabled              true/false
  skillNodeCost        cost per node level; 0 = free (only ever lowers costs)
  skillPointsPerLevel  0 = unchanged; set e.g. 3 if the tree won't invest while
                       you have 0 points left
  patchDevSkillTree    also patch the developer tree if present
  logNodes             log every patched node (troubleshooting)

After a game update
  EML re-applies the patch on every start. If the log shows trees=0 or failed>0,
  the mod needs updating.

Credits
  Enshrouded Mod Loader (EML) / kfc-parser by brabb3l - required, not included.
  Auto Loot Plus by Dellemann - the settings reader and helper functions follow its
  code patterns. MIT License (the licence names the author as "cw"); the licence
  text is in "licences\MIT LICENSE.txt".
