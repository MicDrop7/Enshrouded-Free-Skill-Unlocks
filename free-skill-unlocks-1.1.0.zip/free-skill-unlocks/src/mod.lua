--[[
  Free Skill Unlocks v1.1.0  (Enshrouded Mod Loader / EML, Lua data patch)

  * Lowers the skill point cost of every skill tree node (keen::SkillTreeResource.nodes[].costs).
  * Optionally changes keen::BalancingTable.skillPointsPerLevel.

  Nothing else is touched: no recipes, presets, perk or dismantle values.

  Whoever runs the world decides: the player's own game in solo / when hosting, or the dedicated
  server. Install on the server (or host) AND on each player's game, with the same config.txt.

  Not possible with a data patch: removing skill prerequisites. Adding skill tree links makes
  the skill tree show and offer the skills, but the game's unlock check ignores them (tested
  in 1.1.0 development, 2026-11-09).

  Credits: the settings reader and the safe field helpers (strip, field, setField) follow
  the patterns of Auto Loot Plus by Dellemann ("cw" in its licence; MIT License,
  see "licences/MIT LICENSE.txt").
  Requires the Enshrouded Mod Loader (EML / kfc-parser) by brabb3l.
]]

local TAG = "[Free Skill Unlocks]"
local VERSION = "1.1.0"

---------------------------------------------------------------------------
-- Settings
---------------------------------------------------------------------------

local defaults = {
    enabled = true,
    skillNodeCost = 0,
    skillPointsPerLevel = 0,
    patchDevSkillTree = true,
    logNodes = false,
}

local function strip(text)
    return (tostring(text):gsub("^%s+", ""):gsub("%s+$", ""))
end

local function parseBool(value)
    local v = value:lower()
    if v == "true" or v == "1" or v == "yes" or v == "on" then return true end
    if v == "false" or v == "0" or v == "no" or v == "off" then return false end
    return nil
end

local function loadSettings()
    local result = {}
    for key, value in pairs(defaults) do result[key] = value end

    local okExists, exists = pcall(io.exists, "config.txt")
    if not okExists or not exists then
        print(TAG .. " config.txt not found, using defaults")
        return result
    end

    local okRead, text = pcall(io.read_to_string, "config.txt")
    if not okRead or type(text) ~= "string" then
        print(TAG .. " could not read config.txt, using defaults")
        return result
    end

    for rawLine in text:gmatch("[^\r\n]+") do
        local line = strip((rawLine:gsub("[#;].*$", "")))
        local key, value = line:match("^([%w_]+)%s*=%s*(.-)$")
        if key and defaults[key] ~= nil then
            if type(defaults[key]) == "boolean" then
                local b = parseBool(value)
                if b ~= nil then result[key] = b end
            else
                result[key] = tonumber(value) or result[key]
            end
        elseif key then
            print(TAG .. " unknown setting ignored: " .. key)
        end
    end
    return result
end

local function clampInt(value, low, high)
    value = math.floor(tonumber(value) or 0)
    if value < low then return low end
    if value > high then return high end
    return value
end

---------------------------------------------------------------------------
-- Helpers (game data fields are accessed defensively)
---------------------------------------------------------------------------

local function field(object, key)
    if object == nil then return nil end
    local ok, value = pcall(function() return object[key] end)
    if ok then return value end
end

local function setField(object, key, value)
    if object == nil then return false end
    return (pcall(function() object[key] = value end))
end

-- keen::HashKey32 is { value = u32 }; accept a bare number too.
local function hashOf(h)
    if type(h) == "number" then return h end
    return tonumber(field(h, "value"))
end

local function resourcesOf(typeName)
    local ok, list = pcall(game.assets.get_resources_by_type, typeName)
    if ok and type(list) == "table" then return list end
    return {}
end

local function skillTrees(cfg)
    local trees = {}
    for _, r in ipairs(resourcesOf("keen::SkillTreeResource")) do table.insert(trees, r) end
    if cfg.patchDevSkillTree then
        for _, r in ipairs(resourcesOf("keen::DevSkillTreeResource")) do table.insert(trees, r) end
    end
    return trees
end

local function environment()
    local side = "unknown"
    local canPatch = true
    pcall(function()
        if loader.is_server then side = "server"
        elseif loader.is_client then side = "client" end
        if loader.features and loader.features.patch == false then canPatch = false end
    end)
    return side, canPatch
end

---------------------------------------------------------------------------
-- Patch: skill costs
---------------------------------------------------------------------------

local function patchSkillCosts(cfg, trees)
    local stats = { nodes = 0, changed = 0, alreadyCheap = 0, failed = 0 }

    for _, resource in ipairs(trees) do
        local nodes = field(field(resource, "data"), "nodes")
        if nodes then
            for _, node in ipairs(nodes) do
                stats.nodes = stats.nodes + 1
                local cost = tonumber(field(node, "costs"))
                if cost == nil then
                    stats.failed = stats.failed + 1
                elseif cost <= cfg.skillNodeCost then
                    stats.alreadyCheap = stats.alreadyCheap + 1
                elseif setField(node, "costs", cfg.skillNodeCost) then
                    stats.changed = stats.changed + 1
                    if cfg.logNodes then
                        print(string.format("%s node %s (%s): cost %d -> %d", TAG,
                            tostring(hashOf(field(node, "id"))), tostring(field(node, "type")),
                            cost, cfg.skillNodeCost))
                    end
                else
                    stats.failed = stats.failed + 1
                end
            end
        end
    end
    return stats
end

---------------------------------------------------------------------------
-- Patch: skill points per level
---------------------------------------------------------------------------

local function patchSkillPointsPerLevel(cfg)
    local tables, vanilla = 0, nil
    for _, resource in ipairs(resourcesOf("keen::BalancingTable")) do
        local data = field(resource, "data")
        local current = tonumber(field(data, "skillPointsPerLevel"))
        if current ~= nil then
            vanilla = vanilla or current
            if cfg.skillPointsPerLevel > 0 and current ~= cfg.skillPointsPerLevel then
                if setField(data, "skillPointsPerLevel", cfg.skillPointsPerLevel) then
                    tables = tables + 1
                end
            end
        end
    end
    return tables, vanilla
end

---------------------------------------------------------------------------
-- Run
---------------------------------------------------------------------------

local cfg = loadSettings()
local side, canPatch = environment()

if not cfg.enabled then
    print(TAG .. " v" .. VERSION .. " disabled in config.txt (" .. side .. ")")
    return
end

cfg.skillNodeCost = clampInt(cfg.skillNodeCost, -1, 65535)
cfg.skillPointsPerLevel = clampInt(cfg.skillPointsPerLevel, 0, 255)

if not canPatch then
    print(TAG .. " WARNING: the loader reports patching is not available here; changes will not be applied")
end

local trees = skillTrees(cfg)

local costText
if cfg.skillNodeCost < 0 then
    costText = "costs unchanged (skillNodeCost=-1)"
else
    local s = patchSkillCosts(cfg, trees)
    costText = string.format("nodes=%d costLoweredTo%d=%d alreadyAtOrBelow=%d failed=%d",
        s.nodes, cfg.skillNodeCost, s.changed, s.alreadyCheap, s.failed)
    if s.failed > 0 then print(TAG .. " WARNING: " .. s.failed .. " node cost(s) could not be patched") end
end

local spTables, spVanilla = patchSkillPointsPerLevel(cfg)

print(string.format("%s v%s on %s: trees=%d | %s | skillPointsPerLevel %s%s",
    TAG, VERSION, side, #trees, costText, tostring(spVanilla),
    (cfg.skillPointsPerLevel > 0 and spTables > 0) and (" -> " .. cfg.skillPointsPerLevel) or " (unchanged)"))

if #trees == 0 then
    print(TAG .. " WARNING: no skill tree found in this build; the game data layout may have changed (update the mod)")
end
